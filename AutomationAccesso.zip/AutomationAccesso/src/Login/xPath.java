package Login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class xPath {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String baseURL = "http://newtours.demoaut.com/";
		WebDriver driver = new ChromeDriver();
		
		
		driver.get(baseURL);
		String innerText = driver.findElement(By.xpath("//table[@width=\"270\"]/tbody/tr[4]/td")).getText();
		System.out.println(innerText);
		
		
	}

}
