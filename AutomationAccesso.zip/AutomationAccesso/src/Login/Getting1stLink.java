package Login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Getting1stLink {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String baseURL = "http://demo.guru99.com/test/link.html";
		System.setProperty("webdriver.chrome.driver","C:\\Automation/Drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get(baseURL);
		driver.findElement(By.linkText("click here")).click();
		System.out.println("Title of this page is: " + driver.getTitle());
		driver.quit();
	}

}
